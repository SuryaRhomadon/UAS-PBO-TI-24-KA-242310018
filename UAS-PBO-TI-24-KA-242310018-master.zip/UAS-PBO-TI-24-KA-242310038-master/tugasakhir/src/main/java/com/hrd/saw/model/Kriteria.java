package com.hrd.saw.model;

public class Kriteria {
    private int id;
    private String namaKriteria;
    private String tipe;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNamaKriteria() { return namaKriteria; }
    public void setNamaKriteria(String namaKriteria) { this.namaKriteria = namaKriteria; }

    public String getTipe() { return tipe; }
    public void setTipe(String tipe) { this.tipe = tipe; }
}
