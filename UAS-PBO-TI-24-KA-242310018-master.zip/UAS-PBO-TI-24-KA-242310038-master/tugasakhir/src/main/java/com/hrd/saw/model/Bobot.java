package com.hrd.saw.model;

public class Bobot {
    private int idBobot;
    private int idKriteria;
    private double nilaiBobot;

    public int getIdBobot() { return idBobot; }
    public void setIdBobot(int idBobot) { this.idBobot = idBobot; }

    public int getIdKriteria() { return idKriteria; }
    public void setIdKriteria(int idKriteria) { this.idKriteria = idKriteria; }

    public double getNilaiBobot() { return nilaiBobot; }
    public void setNilaiBobot(double nilaiBobot) { this.nilaiBobot = nilaiBobot; }
}
